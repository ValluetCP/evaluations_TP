# Intégration

Intégration de la maquette du restaurant *Ce soir*

La page est en full-width.
Typo Google Font : 'Caveat Brush'.
Font Awesome pour les icônes des réseaux sociaux.

Mettre en place une hierarchie de dossier correcte.
  projet >
    [img]>
    [css]>
      style.css
    index.html

Vous trouverez des textures pour le background du header ici :
  [cg_texture]('http://www.textures.com/browse/bare/45356')


* Les images sont dans le dossier img. A ranger dans l'arborescence du dossier
* Pour le logo vous utiliserez le fichier cerf.svg

Bon travail !